import React from 'react'
import  '../estilos/hermes.css'

function Hermesconandy(props) {
  return (
    <div>
      <h1 className="hermes" id="hermes-menu">HERMES</h1>
         <div className="container ">
        <div className="row d-flex ">
            <div className="col-12 col-lg-6 d-flex justify-content-center">
                <img className="img-fluid" src="src\assets\andy señalando.png" alt=""/>
            </div>
            <div className="col-12 col-lg-6 d-flex justify-content-center">
              <div className="tex">
                <p className="d-flex justify-content-center">Notamos una gran falencia en la distinción de las señales de tránsito preventivas, 
                encontrando que el 42% de los accidentes es por la confusión de las señales preventivas; 
                permitiendo que con la ayuda de la enseñanza podamos prevenir accidentes, 
                ya que estas hacen referencia y enfatizan a la prevención y conservación de la vida.</p> 
                <p className="d-flex justify-content-center">{props.textoandy}</p>
              </div>
            </div>
        </div>
    </div>
    </div>
  )
}

export default Hermesconandy