import React from 'react'
import '../estilos/hermes.css'

function Integrantes(props) {
    return (
        < div >
        <section className="container Equipo">
        <h3 className="tituloequipo">{props.tituloequipo}</h3>
        <div className="row">
        <div className="card-group">
            <div className="card d-flex justify-content-center ">
              <img src="src\assets\Ana.png" className="d-flex justify-content-center card-img-yo1 img-fluid" alt="..."/>
              <div className="card-body">
                <h5 className="card-title">ANA</h5>
                <h4 className="subtitulos">Diseñadora y redactora</h4>
                <p className="card-text">Soy estudiante de producción multimedia, tengo 18 años, me caracterizo por ser perseverante, creativa, autodidacta y proactiva, lo que más me apasiona es la producción músical, audiovisual y el diseño, en mis tiempos libres me gusta hacer ejercicio, dibujar,leer, descansar y escuchar música.</p>
              </div>
            </div>
            <div className="card">
              <img src="src\assets\Daniela.png" className="d-flex justify-content-center card-img-yo1 img-fluid" alt="..."/>
              <div className="card-body">
                <h5 className="card-title">{props.daniela}</h5>
                <h4 className="subtitulos">{props.subtitulo}</h4>
                <p className="card-text">{props.textodaniela}</p>
              </div>
            </div>
            <div className="card">
              <img src="src\assets\Karen.png" className="d-flex justify-content-center card-img-yo1 img-fluid" alt="..."/>
              <div className="card-body">
                <h5 className="card-title">KAREN</h5>
                <h4 className="subtitulos">Programadora</h4>
                <p className="card-text">Estudiante de producción de multimedia, tengo 18 años; soy una persona dedicada, proactiva, honesta y símpatica, soy amante a los animales en mis tiempos libres me gusta practicar natación, estar con mis seres queridos y escuchar música.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    
   </div >
  )
}

export default Integrantes