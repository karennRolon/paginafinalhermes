import React from 'react'
import  '../estilos/hermes.css'

function Conocenos(props) {
  return (
    <div>
        <section className=" container amarillo">
        <div className="card-group ">
            <div className="conocenos card">
              <img src="src\assets\personas.png" className="d-flex justify-content-center card-img mt-4 ml-120 img-fluid"  alt=""/>
              <div className="card-body">
                <h5 className="card-title">MISIÓN</h5>
                <p className="card-text">{props.mision}</p>
              </div>
            </div>
            <div className=" conocenos card">
              <img src="src\assets\mujer.png" className="d-flex justify-content-center card-img-icono mt-4 img-fluid" alt="..."/>
              <div className="card-body">
                <h5 className="card-title">VISIÓN</h5>
                <p className="card-text">{props.vision}</p>
              </div>
            </div>
            <div className="conocenos card">
              <img src="src\assets\casa2.png" className="d-flex justify-content-center card-img mt-4 img-fluid"  alt="..."/>
              <div className="card-body">
                <h5 className="card-title">OBJETIVO GENERAL</h5>
                <p className="card-text">{props.objetivogeneral}</p>
              </div>
            </div>
          </div>
      </section>

    </div>
  )
}

export default Conocenos