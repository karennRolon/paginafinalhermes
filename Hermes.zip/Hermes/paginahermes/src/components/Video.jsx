import React from 'react'
import '../estilos/hermes.css'

function Video(props) {
  return (
    <div>
        <section className="video" id="video-menu">
        <div className="row d-flex ">
          <div className="col-12 col-lg-6 mt-5">
            <h6>Conócenos</h6>
            <p className="texto-video">{props.videopresentacion}</p>
          </div>
          <div className="col-12 col-lg-6">
            <div className="mt-5 text-center">
      
              <video className="vi" controls="" muted="" autoplay="">
                <source src="src\assets\HERMES (2).mp4"/>
              </video>
        
            </div>
          </div>
         </div>
      </section>
    </div>
  )
}

export default Video