import React from 'react'
import  '../estilos/hermes.css'

function Footer(props) {
  return (
    <div>
        <div className="iconos d-flex justify-content-center p-5 mt-4">
    <div className="icono"><img src="src\assets\Instagram.png" width="110px" height="80px" alt=""/></div>
    <div className="icono"> <img src="src\assets\facebook.png" width="110px" height="80px" alt=""/></div>
    <div className="icono"><img src="src\assets\gmail.png"  width="170px" height="80px" alt=""/></div>
    <div className="icono"><img src="src\assets\twitter.png" width="130px" height="80px" alt=""/></div>
    </div>
</div>
  )
}

export default Footer