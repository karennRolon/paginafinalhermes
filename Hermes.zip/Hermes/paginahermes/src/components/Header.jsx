import React from 'react'
import  '../estilos/hermes.css'

function Header(props) {
  return (
    <div>
          <main className="container">
    <div className="row">
        <div className="col-12 col-lg-3 mt-4">
          <img src="src\assets\logo.png" alt="Logo" className="d-inline-block align-text-top"/>
        </div>
        <div className="menu col-12 col-lg-8 d-flex justify-content-end align-items-center fs-4 ">
            <nav class="navbar navbar-expand-lg">
                {/* <!-- Menú hamburguesa --> */}
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                {/* <!-- Menú hamburguesa --> */}
                <div className="collapse navbar-collapse " id="navbarNav" >
                    <ul className="navbar-nav ">
                        <li className="nav-item"><a class="nav-link" aria-current="page" href="">{props.bienvenidos}</a></li>
                        <li className="nav-item" ><a class="nav-link" href="#video-menu">Conócenos</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#hermes-menu">Hermes</a>
                        </li>
                        <li className="nav-item">
                          <a className="nav-link" href="#¡JUEGA YA!-menu">Aventúrate</a>
                      </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</main>

    </div>
  )
}

export default Header