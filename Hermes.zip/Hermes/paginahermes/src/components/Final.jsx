import React from 'react'
import  '../estilos/hermes.css'

function Final(props) {
  return (
    <div>
        <div className="container" >
      <div className="row">
          <div className="mt-4 d-flex justify-content-center align-items-center" id="¡JUEGA YA!-menu">
              <img  className="img-fluid" src="src\assets\ESCENARIO.png"  alt=""/>
          </div>
            <div className="row">
              <div className="col-12 col-lg-12 d-flex justify-content-center mt-2">
                <button className="btn" type="button">{props.click}</button> 
              </div>
          </div>
        </div>
    </div>
</div>
  )
}

export default Final