import React from 'react'
import Conocenos from './components/Conocenos'
import Header from './components/Header'
import Integrantes from './components/Integrantes'
import Slider from './components/Slider'
import Video from './components/Video'
import Hermesconandy from './components/Hermesconandy'
import Final from './components/Final'
import Footer from './components/Footer'

function App() {
  return (
    <div>
      <Header
      bienvenidos="Bienvenidos"/>
      <Slider/>

      <Video
      videopresentacion="En la actualidad se ha evidenciado que es más fácil aprender por medio
      de vídeos, canciones e imágenes algún tema con su rango de dificultad,
      por eso sabemos que es muy tedioso aprender de las señales de tránsito
      preventivas de la manera tradicional así que mostramos nuestro
      producto Hermes, como ayuda de aprendizaje hacía los usuarios que
      quieren aprender dinámicamente."/>

      <Conocenos
      mision="Queremos que las personas conozcan y entiendan la importancia de las señales preventivas, evitando más accidentes y conservando la vida."
      vision="Planeamos que para el 2024 nuestro proyecto se encuentre asociado 
      con varias agencias o academias de conducción para la prevención de la vida."
      objetivogeneral= "Hermes busca enseñar de manera más divertida y menos aburrida el tema de las señales preventivas; por medio de un juego online."
      />

      <Integrantes
      tituloequipo="EQUIPO DE TRABAJO"
      daniela="DANIELA"
      subtitulo="Diseñadora e ilustradora"
      textodaniela="Estudio Producción de multimedia, tengo 18 años, me
      considero una persona proactiva,creativa, perfeccionista y paciente, 
      soy amante del dibujo,la pintura y el diseño; en mis tiempos libres leo, escucho 
      música y realizo pinturas en lienzo."
      />

      <Hermesconandy
      textoandy="Servicio del juego: Este juego online tiene como objetivo, 
      enseñar las señales preventivas. Se hace con el propósito de aprender de forma diferente, 
      más entretenida y menos monótona, también este juego serviría como ayuda para aquellas 
      agencias de conducción que quieran nuestro producto para sus usuarios."
      />

      <Final
      click="¡JUEGA YA!"/>

      <Footer/>

    </div>
  )
}

export default App